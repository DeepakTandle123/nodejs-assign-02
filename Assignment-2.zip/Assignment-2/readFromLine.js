let readLine = require('readline')
let rl = readLine.createInterface(process.stdin,process.stdout)
rl.question("Please enter your name:",function(answer){
    console.log(`Hello ${answer}`)
})