let arg = process.argv[2];
console.log(`Hello ${arg}`)
console.log(process.argv)

