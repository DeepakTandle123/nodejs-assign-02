let name = process.env.USERNAME;
console.log(`Hello ${name}`)
console.log(process.env)